function getClouds(){
 document.getElementById("aboutCondition").innerHTML = "<h3>About Clouds</h3> </ br> </ br> 'In meteorology, a cloud is an aerosol consisting of a visible mass of minute liquid droplets, frozen crystals, or other particles suspended in the atmosphere of a planetary body. Water or various other chemicals may compose the droplets and crystals.' - From Wikipedia"
}

function getMist(){
document.getElementById("aboutCondition").innerHTML = "<h3>About Mist</h3> </ br> </ br> 'Mist is a phenomenon caused by small droplets of water suspended in air. Physically, it is an example of a dispersion. It is most commonly seen where warm, moist air meets sudden cooling, such as in exhaled air in the winter, or when throwing water onto the hot stove of a sauna.' - From Wikipedia"
}

function getRain(){
 document.getElementById("aboutCondition").innerHTML = "<h3>About Rain</h3> </ br> </ br> 'Rain is liquid water in the form of droplets that have condensed from atmospheric water vapor and then become heavy enough to fall under gravity.' - From Wikipedia"
}

function getSnow(){
 document.getElementById("aboutCondition").innerHTML = "<h3>About Snow</h3> </ br> </ br> 'Snow refers to forms of ice crystals that precipitate from the atmosphere (usually from clouds) and undergo changes on the Earth's surface. It pertains to frozen crystalline water throughout its life cycle, starting when, under suitable conditions, the ice crystals form in the atmosphere, increase to millimeter size, precipitate and accumulate on surfaces, then metamorphose in place, and ultimately melt, slide or sublimate away.' - From Wikipedia"
}

function getStorm(){
 document.getElementById("aboutCondition").innerHTML = "<h3>About Thunderstorms</h3> </ br> </ br> 'A thunderstorm, also known as an electrical storm, lightning storm, or thundershower, is a storm characterized by the presence of lightning and its acoustic effect on the Earth's atmosphere, known as thunder. Thunderstorms occur in a type of cloud known as a cumulonimbus. They are usually accompanied by strong winds, heavy rain, and sometimes snow, sleet, hail, or, in contrast, no precipitation at all.' - From Wikipedia"
}

function getHumid(){
document.getElementById("aboutHumidity").innerHTML ="<h3>About Humidity</h3> </ br> </ br> 'Humidity is the amount of water vapour present in air. Water vapour, the gaseous state of water, is generally invisible to the human eye. Humidity indicates the likelihood for precipitation, dew, or fog to be present. The amount of water vapour needed to achieve saturation increases as the temperature increases. As the temperature of a parcel of air decreases it will eventually reach the saturation point without adding or losing water mass. The amount of water vapour contained within a parcel of air can vary significantly. For example, a parcel of air near saturation may contain 28 grams of water per cubic metre of air at 30 °C, but only 8 grams of water per cubic metre of air at 8 °C.' -from Wikipedia"

}
